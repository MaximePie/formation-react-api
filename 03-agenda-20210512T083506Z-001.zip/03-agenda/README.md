Pour lancer le projet :

> npm install
> npm start

Une page dans le navigateur s'ouvre à l'adresse http://localhost:3000

Create React App crée automatiquement un serveur web pour le projet, il n'est donc pas nécessaire d'utiliser MAMP/XAMPP/WampServer